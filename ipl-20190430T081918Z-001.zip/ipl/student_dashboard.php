<?php 
    session_start();
    $dbfname=$_SESSION['First_Name'];
    $dblname=$_SESSION['Last_Name'];
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png" href="rait_logo.jpg"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>   
    <link rel="stylesheet" type="text/css" href="common.css">
    <style type="text/css">
     html body{
        margin:0px;
        padding: 0px;
        
        width: 100%;
        overflow-x: hidden;
        
    }
        #left_box{
            float: left;
            position: relative;
            top: 10px;
            margin-left: 50px;
            border:3px #82152C solid;
        }
        #topbar3{
            width: 750px;
            height: 30px;
            background-color:white;
        }
      #subject {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#subject td, #subject th {
    border: 5px solid #ddd;
    padding: 8px;
}

#subject tr:nth-child(even){background-color:white;}

#subject tr:hover {background-color: #ddd;}

#subject th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: center;
    background-color: #E7E7E7;
    color: #333333;
}
#subject button{
background-color: #424244;
font-size: 20px;
color: white;
    
}
hr{
    background-color:#82152C;
}

</style>
</head>
<body>
    <div id="topbar">
         <div id="raitdashlogo">
            <img src="raitdashlogo.jpg">
        
        </div>
        <div id="manlogo">
            <img src="man.png">
        </div>
        <div id="username">
            <form>
                <input type="text" name="username" value="<?php echo $dbfname." ".$dblname; ?>" readonly>
            </form>
        </div>
    </div>
<div id="topbar2">
    <div id="button_group">
       <a href="student_dashboard.php"> <button>Home</button></a>
       <a href="student_profile.php"> <button>Profile</button></a>
       <a href="index.php">  <button>LogOut</button></a>
    </div>    
</div>
<div id="left_box">
    <p style="font-size: 25px;padding-left:15px;">Academic Status</p>
  <a href="https://drive.google.com/file/d/1WanjgQVCwrosq5coIJLwiClKrLsTBvH8/view?usp=sharing">  <input type="submit" value="Syllabus" style="margin-left: 25px; position: relative; top: -20px; font-size: 20px;background-color:#424244;color:white; cursor: pointer;"></a>
  <hr width="100%" size="5">
  <a href="forum.html">  <input type="submit" value="Forum" style="margin-left: 25px; position: relative; top: -70px;left: 150px; font-size: 20px;background-color:#424244;color:white; "></a>
  <hr width="100%" size="5">
    <div id="topbar3">
        <p style="color:blue;float: left;position: relative;top: -10px;font-weight:700;color:#82152C; margin-left: 10px;">IT-2016-A</p>
        <p style="float:right; position: relative;top: -10px;margin-right:10px;color:#82152C; font-weight: 700 ">Semester V</p>
    </div>
    
       <table id="subject">
        <tr>
            <th><p align="center"> Subject</p> </th>
            <th><p align="center">Instructor</p></th>
            <th><p align="center"> Launch</p></th>
        </tr>
        <tr>
            <td>Microcontroller and Embedded Programming </td>
            <td><pre>Deepali patil
IT-2016-A CCR</pre></td>
            <td><a href="mep.html"><button style="cursor: pointer;">Launch</button></td></a>
        </tr>
        <tr>
            <td>Internet Programming</td>
            <td><pre>Samundiswary Srinivasan
IT-2016-A CCR</pre></td>
            <td><a href="ip.html"><button style="cursor: pointer;">Launch</button></td>
        </tr>
        <tr>
            <td> Cryptography and Network Security </td>
            <td><pre>Anita Patil
IT-2016-A CCR</pre></td>
            <td><a href="cns.html"><button>Launch</button></td>
        </tr>
        <tr>
            <td> Advanced Data Structures and Analysis of Algorithms</td>
            <td><pre>Reshma Gulwani
IT-2016-A CCR</pre></td>
            <td><a href="adsa.html"><button>Launch</button></td>
        </tr>
        <tr>
            <td>Advanced Data Management Technology</td>
            <td><pre>Pallavi Chavan
IT-2016-A CCR</pre></td>
            <td><a href="admt.html"><button>Launch</button></td>
        </tr>
        


       </table>
</div>
<iframe src="https://calendar.google.com/calendar/embed?src=93o6ie93t3neidbliit8l0o28s%40group.calendar.google.com&ctz=Asia%2FCalcutta" style="border: 0" width="500" height="300" frameborder="0" scrolling="no"></iframe>
<div>


</div>
<footer>
    <div>
    <h1 style="float:left;background-color:#000000;color: #424244;height: 125px;width: 100%"><pre>Education is not the learning of many facts
but the training of the mind to think.' - Albert Einstein</pre></h1>
        </div>
    </footer>
</body>
</html>