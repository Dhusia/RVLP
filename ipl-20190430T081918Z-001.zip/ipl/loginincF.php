<?php  
session_start();
if(isset($_POST["submit"]))
{  
  
if(!empty($_POST['Username']) && !empty($_POST['Password']))
{  
    $username=$_POST['Username'];  
    $password=$_POST['Password'];
    $dbfname=$_POST['First_Name'];
    $dblname=$_POST['Last_Name'];

    $con=mysqli_connect('shareddb1e.hosting.stackcp.net','raitrvlp-36370cbe','dyp@rait','raitrvlp-36370cbe') or die(mysqli_error());  
    $query=mysqli_query($con,"SELECT * FROM faculty WHERE Username='$username' AND Password='$password';");
   
    $numrows=mysqli_num_rows($query);  
    if($numrows!=0)  
    {  
    $row=mysqli_fetch_assoc($query);  
    $dbusername=$row['Username'];  
    $dbpassword=$row['Password'];
    $dbfname=$row['First_Name'];
    $dblname=$row['Last_Name'];
        
   if($username == $row['Username'] && $password == $row['Password'])   
    {  
    $_SESSION['Username']=$username;
    $_SESSION['First_Name']=$dbfname;
    $_SESSION['Last_Name']=$dblname;
     
    
   /* Redirect browser */  
    header("Location:faculty_dashboard.php");  
    } 
    else{
    header("Location:Faculty.php");
    }
 
  
   }//else {  
    //echo "All fields are required!";  
    }
} 
     
 
?>